# Azure Functions profile.ps1

# Ensure Az module is imported
if (-not (Get-Module -ListAvailable -Name Az)) {
    Install-Module -Name Az -Force -AllowClobber
}
Import-Module Az -ErrorAction Stop

# Ensure Az.Storage module is imported
if (-not (Get-Module -ListAvailable -Name Az.Storage)) {
    Install-Module -Name Az.Storage -Force -AllowClobber
}
Import-Module Az.Storage -ErrorAction Stop

# Authenticate with Azure PowerShell using MSI
if ($env:MSI_SECRET -and (Get-Module -ListAvailable -Name Az.Accounts)) {
    try {
        Connect-AzAccount -Identity -ErrorAction Stop
    } catch {
        Write-Error "Failed to authenticate to Azure: $_"
        exit 1
    }
}

# You can also define functions or aliases that can be referenced in any of your PowerShell functions.
